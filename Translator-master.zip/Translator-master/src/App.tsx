import { Header } from "./components/Header";
import { Translator } from "./components/Translator";

function App() {
  return (
    <div className="flex flex-col justify-start items-center pb-12 overflow-hidden gap-12 bg-white">
      <Header />
      <Translator />
    </div>
  );
}

export default App;
