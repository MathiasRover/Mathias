function ExplanationCard({id,children}) {
  return (
    <div id={id} className="mx-auto p-6 max-w-[1024px] bg-white rounded-lg shadow-md">
      {children}
    </div>
  );
}
export function AKACode() {
  return (
    <>
      <h2 className="text-2xl">A-K kode</h2>
      <p className="text-sm leading-6 py-3">
        A-K koden er en type kodning, der tillader kommunikation med andre uden
        at være forståelig for uvedkommende. Det er kun de personer, som kender
        de to bogstaver, og i hvilken rækkefølge, som vil kunne løse denne kode.
        Oftest bliver denne kode bare brugt med A-K.
      </p>
      <h3 className="text-lg">
        Hvordan laver jeg eller løser jeg en kode med A-K?
      </h3>
      <p className="text-sm leading-6 py-3">
        For at lave en A-K kode bruger du din kodeløser, eller vælger A-K kode
        oversætteren på denne side. Hvis du bruger denne side, vælger du bare
        A-K og skriver din tekst, så oversætter den selv teksten. Hvis du har
        din kodeløser, skal du først finde det bogstav du ønsker at få oversat i
        øverste række, og derefter bruge det bogstav som står nedenunder.
      </p>
      <p className="text-sm leading-6 py-3">
        Hvis vi oversætter ordet SJOV, bliver det til ÅTYC. Når koden så skal
        løses, skal vi finde bogstaverne i de nederste felter, og tage det
        bogstav der står ovenfor.
      </p>

      <ul>
        <li>Å=Blå ring</li>
        <li>T=Gul ring</li>
        <li>Y= Rød ring</li>
        <li>C=Grøn ring</li>
      </ul>


      <div className="flex flex-col gap-4">
        <img className="w-fit" src="/explanation/image4.png" alt="" />
      </div>

      <h3 className="text-lg"> Med og uden W??</h3>
      <p className="text-sm leading-6 py-3">
        Denne kode bliver både lavet med og uden W, hvilket du skal være
        opmærksom på, da det har stor betydning for om du kan løse koden
        korrekt.
      </p>

      <h3 className="text-lg">A-K kode eller M-Y eller O-P??</h3>
      <p className="text-sm leading-6 py-3">
        Som tidligere nævnt, kan koden også bruges med andre bogstaver end A-K.
        Hvis vi er blevet enige om, at vores koder til hinanden skal løses med
        O-P i stedet for A-K, så skal vi have fat i en O-P oversætter. Den ville
        se sådan her ud. Den bruges på samme måde som beskrevet for A-K, så når
        koden skal laves, findes bogstavet i øverste række, og man bruger
        bogstavet nedenunder. Når modtageren har modtaget koden løses koden igen
        ved at tage det bogstav, som er over det bogstav, som man har fundet i
        nederste række.
      </p>

      <div className="flex flex-col gap-4">
        <img className="w-fit" src="/explanation/image12.png" alt="" />
      </div>
    </>
  );
}

export function Morsekode() {
  return (
    <>
      <h2 className="text-2xl">Morsekode</h2>
      <p className="text-sm leading-6 py-3">
        Morse er et kommunikationssystem, som har været meget udbredt inden for
        søfart. Morse er blevet brugt meget i situationer, hvor man ikke har
        kunnet tale sammen, da det er en simpel kommunikationsform som kan
        sendes ved hjælp af lys eller lyd.
      </p>
      <h3 className="text-lg">Hvordan fungerer morse?</h3>
      <p className="text-sm leading-6 py-3">
        Morse fungerer ved at sende ‘korte’ og ‘lange’ signaler, som oftest er
        tegnet som prikker og streger, som modtageren kan aflæse. Rækkefølgen af
        prikker og streger, som sendes, repræsenterer forskellige bogstaver og
        tal.
      </p>
      <p className="text-sm leading-6 py-3">
        For eksempel: Hvis der sendes en lang lyd (en streg, repræsenteret ved
        "-") efterfulgt af en kort lyd (en prik, repræsenteret ved "."), skal
        modtageren oversætte - . med en morsenøgle. Når der skal kommunikeres et
        nyt bogstav, holdes der en kort pause, og når der startes på et nyt ord,
        holdes en ekstra lang pause. Det samme princip kan bruges, hvis man
        bruger lys i stedet for lyd.
      </p>
      <h3 className="text-lg">Hvordan løser man en morsekode?</h3>
      <p className="text-sm leading-6 py-3">
        Lad os sige, at du har modtaget følgende ord: ..../..-/-./-..//. For at
        oversætte det til bogstaver. Husk, at prikker (.) repræsenterer de hvide
        felter, og streger (-) repræsenterer de røde felter på din morsenøgle.
        Du starter altid fra toppen. Hvis det første er en prik , skal du starte
        på det hvide felt, hvor der står "E", og hvis det er en streg, skal du
        starte på det røde felt, hvor der står "T". Hvis vi så har, at det
        første er en prik, og det næste er en streg, så skal vi gå fra "E" ned
        til "A". På morsenøglen herunder, kan du følge pilen for at se hvordan
        koden ovenfor løses. De røde pile repræsenterer det første bogstav (H),
        de grønne pile repræsenterer det andet bogstav (U), de blå pile
        repræsenterer det tredje bogstav (N), og de sorte pile repræsenterer det
        fjerde bogstav (D). Svaret på morsekoden er altså: Hund
      </p>

      <div className="flex flex-col gap-4">
        <img className="w-fit" src="/explanation/image16.png" alt="" />
      </div>
    </>
  );
}
export function DigitalKode() {
  return (
    <>
      <h2 className="text-2xl">Digital kode</h2>
      <p className="text-sm leading-6 py-3">
        Digital koden adskiller sig fra mange af de kendte koder, da den ikke
        direkte oversættes til et bogstav, når den løses. I stedet for bogstaver
        oversættes koden til tal, som skal bruges i talkoden.
      </p>
      <h3 className="text-lg">Hvordan løser man en digital kode?</h3>
      <p className="text-sm leading-6 py-3">
        For at løse koden skal du følge tallene rundt på kodeløseren, som vil
        give en figur af et digitalt tal. Disse tal skal derefter oversættes med
        talkoden. Når talkoden er løst, vil ordet blive afsløret. Eksempel: Hvis
        koden lyder som følger: 246,124356 213465 246,1356421 246,213465342 Så
        følger vi tallene rundt på kodeløseren, hvilket resulterer i følgende
        tal:
      </p>
      <ul className="text-sm leading-6 py-3">
        <li>Det første tal bliver 12 (1 og 2)</li>
        <li>Det andet tal bliver 5</li>
        <li>Det tredje tal bliver 10 (1 og 0)</li>
        <li>Det fjerde tal bliver 18 (1 og &nbsp;8)</li>
      </ul>

      <div className="flex flex-col gap-4">
        <img className="w-fit" src="/explanation/image9.png" alt="" />
      </div>
      <ul className="text-sm leading-6 py-3">
        <li>Nu har vi tallene 12, 5, 10 og 18</li>
        <li>
          Disse tal skal vi bruge på talkoden, for at finde løsningen til koden
          (12 5 10 18), og svaret er: Lejr
        </li>
      </ul>
    </>
  );
}

export function Talkode() {
  return (
    <>
      <h2 className="text-2xl">Talkode</h2>
      <p className="text-sm leading-6 py-3">
        Talkoden er simpel i sin opbygning, så skal du have oversat bogstaver
        til en talkode, skal du bare tage det tal som står under bogstavet. Hvis
        du skal løse en talkode, skal du tage det bogstav, som står ovenover
        tallet.
      </p>
      <div className="flex flex-col gap-4">
        <img className="w-fit" src="/explanation/image13.png" alt="" />
      </div>
    </>
  );
}

export function Frimurerkode() {
  return (
    <>
      <h2 className="text-2xl">Frimurerkode</h2>
      <h3 className="text-lg">Hvad er en frimurerkode?</h3>
      <p className="text-sm leading-6 py-3">
        Frimurerkoden er en simpel kode, som er let at lære, og som du kan bruge
        til at sende hemmelige beskeder til andre. De færreste forstår, hvad det
        er, medmindre de har lært koden.
      </p>
      <h3 className="text-lg">Hvordan løser jeg en frimurerkode?</h3>
      <p className="text-sm leading-6 py-3">
        Frimurerkoden er opdelt i 3 bokse, hvor der i hver boks er 9 bogstaver.
        I den første boks er bogstaverne fra A til I, i den næste boks er de fra
        J til S, og i den sidste boks er de fra T til Å. Som vist på billedet
        nedenfor er der 1 prik over den anden boks, og 2 prikker over den tredje
        boks. Disse prikker skal du kigge efter, når du løser koden. Hvis der
        ikke er nogen prikker, er koden fra boks 1, og henholdsvis 1 og 2
        prikker indikerer henholdsvis boks 2 og 3. Her er et eksempel på,
        hvordan en frimurerkode løses. Koden kan se sådan ud:
      </p>

      <div className="flex flex-col gap-4">
        <img className="w-fit" src="/explanation/image6.png" alt="" />
      </div>
      <p className="text-sm leading-6 py-3">
        Så skal du finde de steder i boksene, der ser sådan ud, og tage det
        bogstav, der står i feltet.
      </p>

      <ul className="text-sm leading-6 py-3">
        <li> = Grøn cirkel</li>
        <li> = Rød cirkel</li>
        <li> = Gul cirkel</li>
      </ul>

      <p className="text-sm leading-6 py-3">
        Den løste kode giver os ordet: Bål
      </p>
      <div className="flex flex-col gap-4">
        <img className="w-fit" src="/explanation/image3.png" alt="" />
      </div>
    </>
  );
}

export function SMSkode() {
  return (
    <>
      <h2 className="text-2xl">SMS kode</h2>
      <p className="text-sm leading-6 py-3">
        SMS-kode er baseret på gamle tastemobiler, hvor man skulle trykke
        tasterne for at skrive ord.
      </p>
      <p className="text-sm leading-6 py-3">
        De fleste brugte dengang ordbogen, som gættede på ord baseret på
        tastetryk. Men det var også muligt at skrive bogstaverne enkeltvis ved
        at trykke på tasterne det antal gange som svarede til bogstavets plads i
        rækken på tasten.
      </p>
      <h3 className="text-lg">Hvordan løser jeg en SMS kode?</h3>
      <ul className="text-sm leading-6 py-3">
        <li>For eksempel, hvis koden er: 52, 21, 81.</li>
        <li>Det første tal angiver tasten, så det er altså tast nummer 5.</li>
        <li>
          Det næste tal angiver hvor mange pladser henad bogstavet står på
          tasten, og her bliver det altså K (Grøn cirkel).
        </li>
        <li>
          Det næste tal er 21. Det betyder, at vi skal bruge tast nummer 2, og
          bogstav nummer 1, hvilket er A (Rød cirkel).
        </li>
        <li>
          Det sidste bogstav, 81, betyder tast nummer 8 og bogstav nummer 1,
          hvilket er T (Gul cirkel).
        </li>
        <li>Svart bliver så til: Kat</li>
      </ul>

      <div className="flex flex-col gap-4">
        <img className="w-fit" src="/explanation/image2.png" alt="" />
      </div>
    </>
  );
}

export function Mollekode() {
  return (
    <>
      <h2 className="text-2xl">Møllekode</h2>
      <p className="text-sm leading-6 py-3">
        Møllekoden er opdelt i to dele: verdenshjørnerne og en "mølle". Ved at
        bruge verdenshjørnerne kan du finde ud af, hvilke bogstaver der er
        placeret inden i "møllen".
      </p>

      <h3 className="text-lg">Sådan løser du en Møllekode:</h3>
      <p className="text-sm leading-6 py-3">
        Møllekoden er let at lære og giver god mening, når man har lært den.
        Hvert bogstav i koden består af to dele: hvilket verdenshjørne du skal
        kigge mod, og hvor mange pladser fra midten bogstavet findes.
      </p>
      <p className="text-sm leading-6 py-3">
        For eksempel kunne en kode lyde sådan: NV2 Ø2 SV2 Ø3.
      </p>
      <p className="text-sm leading-6 py-3">Det første bogstav er: NV2.</p>
      <p className="text-sm leading-6 py-3">
        Du skal derfor kigge mod nord-vest og gå to pladser ud fra midten,
        hvilket giver bogstavet K (Grøn cirkel). Det næste bogstav er Ø2, så du
        går mod øst 2 gange, og finder bogstavet N (Rød cirkel). Det tredje
        bogstav finder du ved at gå syd-vest 2 gange, hvor du finder bogstavet I
        (Blå cirkel). Det sidste bogstav i koden er mod øst 3 gange, hvilket
        fører dig til bogstavet V (Gul cirkel).
      </p>
      <p className="text-sm leading-6 py-3">Koden bliver til: Kniv.</p>

      <div className="flex flex-col gap-4">
        <img className="w-fit" src="/explanation/image17.png" alt="" />
      </div>
    </>
  );
}

export function Binary() {
  return (
    <>
      <h2 className="text-2xl">Binær</h2>
      <p className="text-sm leading-6 py-3">
        Binærkoden er baseret på det binære talsystem, hvor kun 0 og 1 anvendes.
        Det er en simpel struktur, der følger et mønster, der begynder med 1,
        derefter 10, 11, 100, 101, 110, 111, 1000, osv.
      </p>

      <h3 className="text-lg">Binærkode som krypteringsmetode</h3>
      <p className="text-sm leading-6 py-3">
        Vi anvender til tider binærkode som kryptering til forskellige opgaver
        eller løb. Det smarte ved binærkode er, at hvis man kender systemet,
        behøver man ikke at have en kodeløser med sig. Man kan blot skrive de
        binære tal ned på papir og derefter tilføje bogstaverne.
      </p>
      <h3 className="text-lg">Hvordan løser man en binærkode?</h3>
      <p className="text-sm leading-6 py-3">
        Den nemmeste måde at løse en binær kode er ved at have en kodeløser med
        sig, hvor man forbinder tallene i opgaven med de bogstaver, der står ud
        for det binære tal.
      </p>
      <p className="text-sm leading-6 py-3">
        Den nemmeste måde at løse en binær kode er ved at have en kodeløser med
        sig, hvor man forbinder tallene i opgaven med de bogstaver, der står ud
        for det binære tal.
      </p>
      <p className="text-sm leading-6 py-3">
        Hvis vi har en kode, der lyder: 10011, 01010, 01111, 10110 Så ser vi i
        kodeløseren efter matchende steder.
      </p>
      <p className="text-sm leading-6 py-3">
        Det første match er, hvor den grønne cirkel er, og det giver et S.
      </p>
      <p className="text-sm leading-6 py-3">
        Det andet match er, hvor den røde cirkel er, og det giver et J.
      </p>
      <p className="text-sm leading-6 py-3">
        Det tredje match er, hvor den blå cirkel er, og det giver et O.
      </p>
      <p className="text-sm leading-6 py-3">
        Det fjerde og sidste match er, hvor den gule cirkel er, og det giver et
        V.
      </p>
      <p className="text-sm leading-6 py-3">
        Dermed har vi løst koden, og svaret er "Sjov".
      </p>
      <div className="flex flex-col gap-4">
        <img className="w-fit" src="/explanation/image8.png" alt="" />
      </div>
    </>
  );
}

export function Spejdkode() {
  return (
    <>
      <h2 className="text-2xl">Spejd kode</h2>
      <p className="text-sm leading-6 py-3">
        Spejd-kode, også kendt som kodeords-kode, er struktureret på en måde,
        der ligner A-K koden. Det er en kode, der kun kan løses, hvis man kender
        det rigtige ord.
      </p>

      <h3 className="text-lg">Hvad er en kodeords kode?</h3>
      <p className="text-sm leading-6 py-3">
        Kodeords-koden er opbygget ved at bogstaverne står parvis overfor
        hinanden i to rækker arrangeret sådan, at de første 14 bogstaver i
        alfabetet står øverst, og de sidste 14 står nederst.
      </p>
      <p className="text-sm leading-6 py-3">
        Dog er der et twist: ordet "kode" skal stå først i den øverste linje.
        Derefter følger A, B og C, men vi hopper over D og E, da de allerede er
        inkluderet. Dette mønster fortsætter. Hvis det næste bogstav allerede er
        med i ordet, springes det over. Dog skal du være opmærksom på, at der
        ikke er to af de samme bogstaver i det ord, du vælger!
      </p>
      <h3 className="text-lg">Hvordan løser jeg en kodeords-kode?</h3>
      <p className="text-sm leading-6 py-3">
        Hvis bruger ordet spejd som kodeordet, og vil oversætte ordet TELT
        kommer koden til at være: AOÅA
      </p>
      <p className="text-sm leading-6 py-3">
        Da vi kender kodeordet, som er brugt til at lave koden, så løser vi
        løser vi den ved at finde bogstaverne i kode oversætteren. løsningen
        bliver så dee bogstaver, der står enten nedenunder eller ovenover de
        bogstaver vi ønsker oversat.
      </p>
      <p className="text-sm leading-6 py-3">A=T (Rød cirkel)</p>
      <p className="text-sm leading-6 py-3">O=E (Grøn cirkel)</p>
      <p className="text-sm leading-6 py-3">Å=L (Blå cirkel)</p>
      <p className="text-sm leading-6 py-3">A=T (Rød cirkel)</p>
      <div className="flex flex-col gap-4">
        <img className="w-fit" src="/explanation/image14.png" alt="" />
      </div>
    </>
  );
}

export function Semafor() {
  return (
    <>
      <h2 className="text-2xl">Semafor</h2>
      <p className="text-sm leading-6 py-3">
        Semafor er en metode til at signalere ved hjælp af flag, der holdes i
        hænderne, og løftes i forskellige positioner ud fra kroppen afhængigt af
        det bogstav, som man ønsker at signalere.
      </p>
      <p className="text-sm leading-6 py-3">
        Det minder lidt om at morse med flag, men i modsætning til morse, hvor
        man sender prikker og streger for at danne et bogstav, har hver
        flagposition i semafor sit eget bogstav.
      </p>
      <p className="text-sm leading-6 py-3">
        Måden at løse semaforkoden på er ved at finde de positioner som der
        bliver sendt eller er tegnet. Find dem i en kodeløser og tag det bogstav
        som står nedenunder.
      </p>

      <div className="flex flex-col gap-4">
        <img className="w-fit" src="/explanation/image1.png" alt="" />
      </div>
    </>
  );
}

export function DancingMen() {
  return (
    <>
      <h2 className="text-2xl">Dancing Men</h2>
      <p className="text-sm leading-6 py-3">
        "Dancing Men" er en kode, der stammer fra Sherlock Holmes, og nu også
        bliver brugt som en generel kode.
      </p>
      <p className="text-sm leading-6 py-3">
        Dancing Men bruger figurer af tændstikmænd, som står på forskellige
        måder. Hver af disse forskellige positioner repræsenterer et bogstav.
      </p>
      <p className="text-sm leading-6 py-3">
        Ligesom ved Semafor skal du finde den figur som passer på det der er
        vist og så tage det bogstav som står under figuren.
      </p>

      <div className="flex flex-col gap-4">
        <img className="w-fit" src="/explanation/image15.png" alt="" />
      </div>
    </>
  );
}

export function Runer() {
  return (
    <>
      <h2 className="text-2xl">Runer (Ældre runer og middelalder runer)</h2>
      <p className="text-sm leading-6 py-3">
        Runer, når de anvendes til koder, er opdelt i to forskellige grupper:
        middelalder runer og ældre runer.
      </p>
      <p className="text-sm leading-6 py-3">
        Desværre kan ikke alle bogstaver oversættes til runer. Middelalder
        runerne har flere tegn til oversættelse og bruges derfor oftest. Hvis
        man har et tegn, der ikke findes på listen, er det dog ofte muligt at
        gætte sig frem til det enkelte bogstav, hvis man kan oversætte de fleste
        andre bogstaver i en kode.
      </p>
      <p className="text-sm leading-6 py-3">
        Runer er et skriftsprog, der blev brugt fra cirka år 200 og frem til år
        1000. Der har været flere forskellige runetegn gennem tiden.
      </p>
      <h3 className="text-lg">Middelalderruner</h3>
      <div className="flex flex-col gap-4">
        <img className="w-fit" src="/explanation/image7.png" alt="" />
      </div>

      <h3 className="text-lg">Ældre runer</h3>
      <div className="flex flex-col gap-4">
        <img className="w-fit" src="/explanation/image5.png" alt="" />
      </div>

      <h3 className="text-lg">Hvordan løser jeg runer?</h3>

      <p className="text-sm leading-6 py-3">
        Måden at løse runer på er ved at identificere tegnet på kodeløseren for
        enten ældre runer eller middelalderruner, og så bruge det bogstav som
        står nedenunder.
      </p>
    </>
  );
}

export function Blindskrift() {
  return (
    <>
      <h2 className="text-2xl">Blindskrift</h2>
      <p className="text-sm leading-6 py-3">
        Blindskrift er en kode, der består af prikker, hvilket gør det muligt
        for blinde at læse. Blinde kan ved at føle prikkerne med fingrene mærke,
        hvilke bogstaver de har med at gøre. Der er store og små prikker, og
        afhængigt af placeringen af prikkerne dannes et bogstav. Vi bruger også
        blindskrift som en del af de spejderkoder, som vi bruger på løb og
        aktiviteter.
      </p>
      <p className="text-sm leading-6 py-3">
        Den nemmeste måde at løse en blindskrift kode er ved at bruge en kode
        løser, hvor de forskellige ”symboler” er, og hvor bogstavet står under
        ”symbolerne”.
      </p>

      <div className="flex flex-col gap-4">
        <img className="w-fit" src="/explanation/image10.png" alt="" />
      </div>
    </>
  );
}

export function Fonetiskalfabet() {
  return (
    <>
      <h2 className="text-2xl">Fonetisk alfabet</h2>
      <p className="text-sm leading-6 py-3">
        Det fonetiske alfabet er ikke en af de mest almindelige koder, som
        anvendes til spejder. Dog anvendes det ofte i radiokommunikation for at
        undgå fejlfortolkninger, når der sendes beskeder. Dette skyldes, at
        visse bogstaver kan lyde ens gennem en radio, så ved at bruge det
        fonetiske alfabet undgås misforståelser.
      </p>
      <p className="text-sm leading-6 py-3">
        Det fonetiske alfabet er opbygget således, at hvert bogstav har sit eget
        tilhørende ord. Når en besked sendes, lyttes der efter ordene, der
        repræsenterer hvert bogstav. Når alle ordene er modtaget, sammensættes
        det første bogstav fra hvert ord for at danne ordet eller sætningen fra
        beskeden.
      </p>
      <p className="text-sm leading-6 py-3">
        Eksempel på en besked: Kilo Oscar Delta Echo Mike Alfa Sierra Kilo India
        November Echo November
      </p>

      <p className="text-sm leading-6 py-3">
        Ved at tage det første bogstav fra hvert ord dannes følgende:
        kodemaskinen
      </p>

      <div className="flex flex-col gap-4">
        <img className="w-fit" src="/explanation/image11.jpg" alt="" />
      </div>
    </>
  );
}

export function Explanation() {
  return (
    <div>
      <nav className="flex max-w-[1024px] gap-12 flex-wrap items-center justify-center py-4 bg-gray-800 text-white">
        <a href="#ak-kode" className="hover:bg-gray-700">
          A-K kode
        </a>
        <a href="#morsekode" className="hover:bg-gray-700">
          Morsekode
        </a>
        <a href="#digital-kode" className="hover:bg-gray-700">
          Digital kode
        </a>
        <a href="#talkode" className="hover:bg-gray-700">
          Talkode
        </a>
        <a href="#frimurerkode" className="hover:bg-gray-700">
          Frimurerkode
        </a>
        <a href="#sms-kode" className="hover:bg-gray-700">
          SMS kode
        </a>
        <a href="#mollekode" className="hover:bg-gray-700">
          Møllekode
        </a>
        <a href="#binary" className="hover:bg-gray-700">
          Binær
        </a>
        <a href="#spejdkode" className="hover:bg-gray-700">
          Spejdkode / Kodeordskode
        </a>
        <a href="#semafor" className="hover:bg-gray-700">
          Semafor
        </a>
        <a href="#dancing-men" className="hover:bg-gray-700">
          Dancing Men
        </a>
        <a href="#runer" className="hover:bg-gray-700">
          Runer (Ældre runer og middelalder runer)
        </a>
        <a href="#blindskrift" className="hover:bg-gray-700">
          Blindskrift
        </a>
        <a href="#fonetisk-alfabet" className="hover:bg-gray-700">
          Fonetisk alfabet
        </a>
      </nav>

      <ExplanationCard id="ak-kode">
        <AKACode />
      </ExplanationCard>

      <ExplanationCard id="morsekode">
        <Morsekode />
      </ExplanationCard>

      <ExplanationCard id="digital-kode">
        <DigitalKode />
      </ExplanationCard>

      <ExplanationCard id="talkode">
        <Talkode />
      </ExplanationCard>

      <ExplanationCard id="frimurerkode">
        <Frimurerkode />
      </ExplanationCard>

      <ExplanationCard id="sms-kode">
        <SMSkode />
      </ExplanationCard>

      <ExplanationCard id="mollekode">
        <Mollekode />
      </ExplanationCard>

      <ExplanationCard id="binary">
        <Binary />
      </ExplanationCard>

      <ExplanationCard id="spejdkode">
        <Spejdkode />
      </ExplanationCard>

      <ExplanationCard id="semafor">
        <Semafor />
      </ExplanationCard>

      <ExplanationCard id="dancing-men">
        <DancingMen />
      </ExplanationCard>

      <ExplanationCard id="runer">
        <Runer />
      </ExplanationCard>

      <ExplanationCard id="blindskrift">
        <Blindskrift />
      </ExplanationCard>

      <ExplanationCard id="fonetisk-alfabet">
        <Fonetiskalfabet />
      </ExplanationCard>
    </div>
  );
}
