import { Translator } from "app/components/Translator";

export function Home() {
  return (
      <Translator />
  );
}

