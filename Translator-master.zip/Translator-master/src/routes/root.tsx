import { Header } from "app/components/Header";
import { Outlet } from "react-router-dom";

export  function Root() {
  return (
    <div className="flex flex-col justify-start items-center pb-12 overflow-hidden gap-12 bg-white">
      <Header />
      <Outlet />
    </div>
  );
}
