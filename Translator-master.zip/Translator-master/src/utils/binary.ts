const binary_set = {
  A: "00001",
  B: "00010",
  C: "00011",
  D: "00100",
  E: "00101",
  F: "00110",
  G: "00111",
  H: "01000",
  I: "01001",
  J: "01010",
  K: "01011",
  L: "01100",
  M: "01101",
  N: "01110",
  O: "01111",
  P: "10000",
  Q: "10001",
  R: "10010",
  S: "10011",
  T: "10100",
  U: "10101",
  V: "10110",
  W: "10111",
  X: "11000",
  Y: "11001",
  Z: "11010",
  Æ: "11011",
  Ø: "11100",
  Å: "11101",
};

const binary_set_r = {
  "00001": "A",
  "00010": "B",
  "00011": "C",
  "00100": "D",
  "00101": "E",
  "00110": "F",
  "00111": "G",
  "01000": "H",
  "01001": "I",
  "01010": "J",
  "01011": "K",
  "01100": "L",
  "01101": "M",
  "01110": "N",
  "01111": "O",
  "10000": "P",
  "10001": "Q",
  "10010": "R",
  "10011": "S",
  "10100": "T",
  "10101": "U",
  "10110": "V",
  "10111": "W",
  "11000": "X",
  "11001": "Y",
  "11010": "Z",
  "11011": "Æ",
  "11100": "Ø",
  "11101": "Å",
};

export const Binary = {
  encode: function (_text: string): string {
    const text = _text.replace(/\n+$/, "").trim();
    return text
      .toUpperCase()
      .split("")
      .map((char) => binary_set[char] || " ") // Use space if character is not found in binary set
      .join(" ");
  },

  decode(_text: string): string {
    const text = _text.replace(/\n+$/, "").trim();
    console.log("text", text);
    const res = text
      .split(" ")
      .map((char) => {
        console.log("char", char);
        return binary_set_r[char] || " ";
      }) // Use space if character is not found in binary set
      .join("");

    console.log("res", res);
    return res;
  },
};
