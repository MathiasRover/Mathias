export const AlfaNrKoden = {
  encode: function (message: string, order: Order) {
    const encodedMessage:  unknown[] = [];
    const mapping = this.getMapping(order);

    for (const char of message.toUpperCase()) {
      if (char === " ") {
        encodedMessage.push("");
      } else if (char >= "A" && char <= "Z") {
        encodedMessage.push(mapping[char]);
      } else if (char === "Æ") {
        encodedMessage.push(mapping["Æ"]);
      } else if (char === "Ø") {
        encodedMessage.push(mapping["Ø"]);
      } else if (char === "Å") {
        encodedMessage.push(mapping["Å"]);
      }
    }

    return encodedMessage.join(" ");
  },

  decode: function (encodedMessage: string, order: unknown) {
    const decodedMessage: unknown[] = [];
    const chars = encodedMessage.split(" ");
    const mapping = this.getMapping(order);

    for (const code of chars) {
      if (code === "") {
        decodedMessage.push(" ");
      } else {
        const char = Object.keys(mapping).find(
          (key) => mapping[key] == parseInt(code),
        );
        decodedMessage.push(char);
      }
    }

    return decodedMessage.join("");
  },

  getMapping: function (order: unknown) {
    const ascending = {
      A: 1,
      B: 2,
      C: 3,
      D: 4,
      E: 5,
      F: 6,
      G: 7,
      H: 8,
      I: 9,
      J: 10,
      K: 11,
      L: 12,
      M: 13,
      N: 14,
      O: 15,
      P: 16,
      Q: 17,
      R: 18,
      S: 19,
      T: 20,
      U: 21,
      V: 22,
      X: 23,
      Y: 24,
      Z: 25,
      Æ: 26,
      Ø: 27,
      Å: 28,
    };

    const descending = {
      A: 28,
      B: 27,
      C: 26,
      D: 25,
      E: 24,
      F: 23,
      G: 22,
      H: 21,
      I: 20,
      J: 19,
      K: 18,
      L: 17,
      M: 16,
      N: 15,
      O: 14,
      P: 13,
      Q: 12,
      R: 11,
      S: 10,
      T: 9,
      U: 8,
      V: 7,
      X: 6,
      Y: 5,
      Z: 4,
      Æ: 3,
      Ø: 2,
      Å: 1,
    };

    const withoutW = {
      A: 1,
      B: 2,
      C: 3,
      D: 4,
      E: 5,
      F: 6,
      G: 7,
      H: 8,
      I: 9,
      J: 10,
      K: 11,
      L: 12,
      M: 13,
      N: 14,
      O: 15,
      P: 16,
      Q: 17,
      R: 18,
      S: 19,
      T: 20,
      U: 21,
      V: 22,
      W: "W",
      X: 23,
      Y: 24,
      Z: 25,
      Æ: 26,
      Ø: 27,
      Å: 28,
    };

    const speechToText = {
      A: "Alpha",
      B: "Bravo",
      C: "Charlie",
      D: "Delta",
      E: "Echo",
      F: "Foxtrot",
      G: "Golf",
      H: "Hotel",
      I: "India",
      J: "Juliett",
      K: "Kilo",
      L: "Lima",
      M: "Mike",
      N: "November",
      O: "Oscar",
      P: "Papa",
      Q: "Quebec",
      R: "Romeo",
      S: "Sierra",
      T: "Tango",
      U: "Uniform",
      V: "Victor",
      W: "Whiskey",
      X: "X-ray",
      Y: "Yankee",
      Z: "Zulu",
      Æ: "Ægir",
      Ø: "Ørken",
      Å: "Århus",
    };

    switch (order) {
      case "ascending":
        return ascending;
      case "descending":
        return descending;
      case "withoutW":
        return withoutW;
      case "speechToText":
        return speechToText;
      default:
        return ascending;
    }
  },
};
