const mappings = {
  danish: {
    "0": "/algorithms/frimurer/1_6.png",
    "1": "/algorithms/frimurer/3_1.png",
    "2": "/algorithms/frimurer/3_2.png",
    "3": "/algorithms/frimurer/3_3.png",
    "4": "/algorithms/frimurer/3_4.png",
    "5": "/algorithms/frimurer/3_5.png",
    "6": "/algorithms/frimurer/3_6.png",
    "7": "/algorithms/frimurer/3_7.png",
    "8": "/algorithms/frimurer/3_8.png",
    "9": "/algorithms/frimurer/3_9.png",
    a: "/algorithms/frimurer/0_1.png",
    " ": "/algorithms/frimurer/0_0.png",
    b: "/algorithms/frimurer/0_2.png",
    c: "/algorithms/frimurer/0_3.png",
    d: "/algorithms/frimurer/0_4.png",
    e: "/algorithms/frimurer/0_5.png",
    f: "/algorithms/frimurer/0_6.png",
    g: "/algorithms/frimurer/0_7.png",
    h: "/algorithms/frimurer/0_8.png",
    i: "/algorithms/frimurer/0_9.png",
    j: "/algorithms/frimurer/1_1.png",
    k: "/algorithms/frimurer/1_2.png",
    l: "/algorithms/frimurer/1_3.png",
    m: "/algorithms/frimurer/1_4.png",
    n: "/algorithms/frimurer/1_5.png",
    o: "/algorithms/frimurer/1_6.png",
    p: "/algorithms/frimurer/1_7.png",
    q: "/algorithms/frimurer/1_8.png",
    r: "/algorithms/frimurer/1_9.png",
    s: "/algorithms/frimurer/2_1.png",
    t: "/algorithms/frimurer/2_2.png",
    u: "/algorithms/frimurer/2_3.png",
    v: "/algorithms/frimurer/2_4.png",
    x: "/algorithms/frimurer/2_5.png",
    y: "/algorithms/frimurer/2_6.png",
    z: "/algorithms/frimurer/2_7.png",
    A: "/algorithms/frimurer/0_1.png",
    B: "/algorithms/frimurer/0_2.png",
    C: "/algorithms/frimurer/0_3.png",
    D: "/algorithms/frimurer/0_4.png",
    E: "/algorithms/frimurer/0_5.png",
    F: "/algorithms/frimurer/0_6.png",
    G: "/algorithms/frimurer/0_7.png",
    H: "/algorithms/frimurer/0_8.png",
    I: "/algorithms/frimurer/0_9.png",
    J: "/algorithms/frimurer/1_1.png",
    K: "/algorithms/frimurer/1_2.png",
    L: "/algorithms/frimurer/1_3.png",
    M: "/algorithms/frimurer/1_4.png",
    N: "/algorithms/frimurer/1_5.png",
    O: "/algorithms/frimurer/1_6.png",
    P: "/algorithms/frimurer/1_7.png",
    Q: "/algorithms/frimurer/1_8.png",
    R: "/algorithms/frimurer/1_9.png",
    S: "/algorithms/frimurer/2_1.png",
    T: "/algorithms/frimurer/2_2.png",
    U: "/algorithms/frimurer/2_3.png",
    V: "/algorithms/frimurer/2_4.png",
    X: "/algorithms/frimurer/2_5.png",
    Y: "/algorithms/frimurer/2_6.png",
    Z: "/algorithms/frimurer/2_7.png",
  },
  english: {
    a: "/algorithms/frimurer/0_1.png",
    " ": "/algorithms/frimurer/0_0.png",
    b: "/algorithms/frimurer/0_2.png",
    c: "/algorithms/frimurer/0_3.png",
    d: "/algorithms/frimurer/0_4.png",
    e: "/algorithms/frimurer/0_5.png",
    f: "/algorithms/frimurer/0_6.png",
    g: "/algorithms/frimurer/0_7.png",
    h: "/algorithms/frimurer/0_8.png",
    i: "/algorithms/frimurer/0_9.png",
    j: "/algorithms/frimurer/1_1.png",
    k: "/algorithms/frimurer/1_2.png",
    l: "/algorithms/frimurer/1_3.png",
    m: "/algorithms/frimurer/1_4.png",
    n: "/algorithms/frimurer/1_5.png",
    o: "/algorithms/frimurer/1_6.png",
    p: "/algorithms/frimurer/1_7.png",
    q: "/algorithms/frimurer/1_8.png",
    r: "/algorithms/frimurer/1_9.png",
    s: "/algorithms/frimurer/t0_1.png",
    t: "/algorithms/frimurer/t0_2.png",
    u: "/algorithms/frimurer/t0_3.png",
    v: "/algorithms/frimurer/t0_4.png",
    x: "/algorithms/frimurer/t1_2.png",
    y: "/algorithms/frimurer/t1_3.png",
    z: "/algorithms/frimurer/t1_4.png",
    A: "/algorithms/frimurer/0_1.png",
    B: "/algorithms/frimurer/0_2.png",
    C: "/algorithms/frimurer/0_3.png",
    D: "/algorithms/frimurer/0_4.png",
    E: "/algorithms/frimurer/0_5.png",
    F: "/algorithms/frimurer/0_6.png",
    G: "/algorithms/frimurer/0_7.png",
    H: "/algorithms/frimurer/0_8.png",
    I: "/algorithms/frimurer/0_9.png",
    J: "/algorithms/frimurer/1_1.png",
    K: "/algorithms/frimurer/1_2.png",
    L: "/algorithms/frimurer/1_3.png",
    M: "/algorithms/frimurer/1_4.png",
    N: "/algorithms/frimurer/1_5.png",
    O: "/algorithms/frimurer/1_6.png",
    P: "/algorithms/frimurer/1_7.png",
    Q: "/algorithms/frimurer/1_8.png",
    R: "/algorithms/frimurer/1_9.png",
    S: "/algorithms/frimurer/t0_1.png",
    T: "/algorithms/frimurer/t0_2.png",
    U: "/algorithms/frimurer/t0_3.png",
    V: "/algorithms/frimurer/t0_4.png",
    X: "/algorithms/frimurer/t1_2.png",
    Y: "/algorithms/frimurer/t1_3.png",
    Z: "/algorithms/frimurer/t1_4.png",
  },
};

export const Frimurerkoden = {
  encode: (text: string, to: Fremurer) => {
    let images: string[] = [];
    if (to === "danish") {
      text.split("").map((char) => {
        images.push(mappings.danish[char]);
      });
    } else {
      text.split("").map((char) => {
        images.push(mappings.english[char]);
      });
    }
    return images;
  },
  decode: (images: string[], from: Fremurer) => {
    let decodedText = "";
    images.forEach((image) => {
      if (from === "danish") {
        const foundKey = Object.keys(mappings.danish).find(
          (key) => mappings.danish[key] === image,
        );
        if (foundKey) {
          decodedText += foundKey;
        }
      } else {
        const foundKey = Object.keys(mappings.english).find(
          (key) => mappings.english[key] === image,
        );
        if (foundKey) {
          decodedText += foundKey;
        }
      }
    });
    return decodedText;
  },
};
