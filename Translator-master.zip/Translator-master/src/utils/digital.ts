const digitalCodes: CodeTranslator = {
  "0": "1356421",
  "1": "246",
  "2": "124356",
  "3": "1243465",
  "4": "134246",
  "5": "213465",
  "6": "135643",
  "7": "1246",
  "8": "213465342",
  "9": "2134246",
};

const digitalDecodes: CodeTranslator = {
  "1356421":"0",
  "246": "1",
  "124356": "2",
  "1243465": "3",
  "134246": "4",
  "213465": "5",
  "135643": "6",
  "1246": "7",
  "213465342": "8",
  "2134246": "9",
};
export const digital = {
  encode: (text: string): string => {
    const code = text
      .replace(/[^0-9\s]/g, "")
      .split("")
      .map((char) => digitalCodes[char] || " ")
      .join(" ");
    return code;
  },
  decode: (code: string): string => {
    return code
      .replace(/\n+$/, "")
      .trim()
      .split(" ")
      .map((chunk) => digitalDecodes[chunk] || " ")
      .join("");
  },
};
