interface Cipher {
  text: string;
  shift: number;
  forward: boolean;
  excludeLetter?: string;
}
/**
 *
 * @param text
 * @param forward // true for A-K, false for K-A
 * @param excludeLetter // excludeLetter W
 * @returns
 */
function cipherEncrypt({
  text,
  shift,
  forward = false,
  excludeLetter,
}: Cipher): string {
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZÆØÅabcdefghijklmnopqrstuvwxyzæøå";
  const shiftedAlphabet = forward
    ? alphabet.slice(shift) + alphabet.slice(0, shift)
    : alphabet.slice(-shift) + alphabet.slice(0, -shift);

  return text
    .split("")
    .map((char) => {
      const isUpperCase = char === char.toUpperCase();
      char = char.toUpperCase();

      if (excludeLetter && char === excludeLetter.toUpperCase()) {
        return char;
      }

      let num = forward ? 0 : 7;
      let char_index = alphabet.indexOf(char);
      let index = char_index >= num ? char_index - num : alphabet.length - num;

      if (index !== -1) {
        const newChar = shiftedAlphabet.charAt(index);
        return isUpperCase ? newChar : newChar.toLowerCase();
      }

      return char;
    })
    .join("");
}

export const ceaser = {
  encode: cipherEncrypt,
  decode: ({ text, shift, excludeLetter }) => {
    return cipherEncrypt({
      text,
      shift,
      forward: false,
      excludeLetter,
    });
  },
};
