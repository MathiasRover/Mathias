export const media_encode = {
  encode: (text: string, to: MediaAlogrithms) => {
    let arr:string[] = []

    if(to ==="dangin_men") {
      arr = text
      .trim()
      .split("");
    }else {
     arr = text
      .replace(/[^a-zA-Z¥ÆØÅæøå\s1-9]/g, "")
      .trim()
      .split("");
    }

    const images: string[] = [];

    arr.forEach((char, index) => {
      if (
        (`${char}${arr[index + 1]}` == "ij" && to == "middelalder_runer") ||
        (`${char}${arr[index + 1]}` == "i j" && to == "middelalder_runer")
      ) {
        images.push(`/algorithms/${to}/${"IJ"}.jpg`);
      } else {
        images.push(
          `/algorithms/${to}/${char == " " ? "_" : char.toUpperCase()}.jpg`,
        );
      }
    });
    console.log("images", images);
    return images;
  },
};
