import { useRef } from "react";
import html2canvas from "html2canvas";

type DivRefType = React.RefObject<HTMLDivElement>;

const userConverter = (): {
  divRef: DivRefType;
  saveAsImage: (format: string) => void;
  saveAsPDF: () => void;
} => {
  const divRef: DivRefType = useRef(null);

  const saveAsImage = (format: string) => {
    // @ts-ignore
    html2canvas(divRef.current, {
      // backgroundColor: "transparent",
    }).then((canvas) => {
      const dataURL = canvas.toDataURL(`image/${format}`);

      // Create a link element and trigger a download
      const link = document.createElement("a");
      link.href = dataURL;
      link.download = `image.${format}`;
      link.click();
    });
  };

  const saveAsPDF = () => {
    // Add text-based content directly to the PDF
    const mywindow = window.open("", "PRINT", "height=400,width=600");

    if (divRef.current && mywindow) {
      mywindow.document.write(divRef.current.innerHTML);
      mywindow.document.close();
      mywindow.print();
      mywindow.onafterprint = function () {
        mywindow.close();
      };
    }
  };

  return { divRef, saveAsImage, saveAsPDF };
};

export default userConverter;
