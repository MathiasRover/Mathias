export function backwards({ text, no_spaces, random_spaces }: Backward) {
  // Remove spaces if specified
  if (no_spaces) {
    text = text.replace(/\s/g, "");
  }

  // Convert the string to an array of characters, reverse it, and then join back into a string
  let reversedString = text.split("").reverse().join("");

  // Insert random spaces if specified
  if (random_spaces) {
    reversedString = randomSpaces(reversedString);
  }

  return reversedString;
}

// Function to insert random spaces
function randomSpaces(text: string) {
  const spacesCount = Math.floor((Math.random() * text.length) / 2);
  const randomIndexes = Array.from({ length: spacesCount }, () =>
    Math.floor(Math.random() * text.length),
  );

  randomIndexes.forEach((index) => {
    text = text.substring(0, index) + " " + text.substring(index);
  });

  return text;
}
