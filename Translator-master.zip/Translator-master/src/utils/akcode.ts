interface CodeOptions {
  start1: string;
  start2: string;
  noW: boolean;
}

const generateAlphabet = (start: string, noW: boolean): string => {
  let alphabet = "";

  let startCharCode = start.toUpperCase().charCodeAt(0);

  // Generate uppercase letters from A to Z
  for (let i = startCharCode; i < startCharCode + 26; i++) {
    const char_from_code = String.fromCharCode(i > 90 ? i - 26 : i);
    if (noW && char_from_code.toUpperCase() === "W") {
      alphabet += "";
    } else {
      alphabet += char_from_code;
    }

    if (char_from_code === "Z") {
      alphabet += "ÆØÅ";
    }
    console.log("alphabet", alphabet);
  }

  // Generate lowercase letters from a to z
  startCharCode = start.toLowerCase().charCodeAt(0);
  for (let i = startCharCode; i < startCharCode + 26; i++) {
    const char_from_code = String.fromCharCode(i > 122 ? i - 26 : i);
    if (noW && char_from_code.toUpperCase() === "W") {
      alphabet += "";
    } else {
      alphabet += char_from_code;
    }

    if (char_from_code === "z") {
      alphabet += "æøå";
    }
  }

  return alphabet;
};

export const aKCode = {
  encode: (text: string, options: CodeOptions): string => {
    const { start1, start2, noW } = options;
    const alphabet1 = generateAlphabet(start1, noW);
    const alphabet2 = generateAlphabet(start2, noW);
    console.log("noW", noW);
    console.log("alphabet1", alphabet1);
    console.log("alphabet2", alphabet2);
    let encoded = "";


    for (let i = 0; i < text.length; i++) {
      const char = text[i];
      const index = alphabet1.indexOf(char);
      if (index !== -1) {
        encoded += alphabet2[index] || " ";
        console.log("encoded", encoded);
      } else {
        encoded += noW && char.toLowerCase() === "w" ? " " : char;
      }
    }

    return encoded;
  },
  decode: (code: string, options: CodeOptions): string => {
    const { start1, start2, noW } = options;
    const alphabet1 = generateAlphabet(start1, noW);
    const alphabet2 = generateAlphabet(start2, noW);

    let decoded = "";
    for (let i = 0; i < code.length; i++) {
      const char = code[i].toUpperCase();
      const index = alphabet2.indexOf(char);
      if (index !== -1) {
        decoded += noW && alphabet1[index] !== "W" ? alphabet1[index] : "W";
      } else {
        decoded += char;
      }
    }

    return decoded;
  },
};

// Example usage
