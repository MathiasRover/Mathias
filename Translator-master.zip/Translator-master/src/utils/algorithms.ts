import {
  Binary,
  aKCode,
  backwards,
  digital,
  morse,
  mollekode,
  phonetic,
  sms,
  talkode,
} from ".";
import { kodeordsKode } from "./kodeordsKode";
import { media_encode } from "./media";

export const algorithms: Algorithm[] = [
  {
    name: "A-K kode",
    options: [
      {
        name: "A-K",
        entry: function (text: string, start1: string, start2: string) {
          return aKCode.encode(text, {
            start1,
            start2,
            noW: false,
          });
        },
      },

      {
        name: "Uden W?",
        entry: function (text: string, start1: string, start2: string) {
          return aKCode.encode(text, {
            start1,
            start2,
            noW: true,
          });
        },
      },
    ],
  },
  {
    name: "Baglæns",
    options: [
      {
        name: "Baglæns",
        entry: function (text: string) {
          return backwards({ text, no_spaces: false, random_spaces: false });
        },
      },
      {
        name: "Fjern mellemrum",
        entry: function (text: string) {
          return backwards({ text, no_spaces: true });
        },
      },
      {
        name: "Random mellemrum",
        entry: function (text: string) {
          return backwards({ text, no_spaces: false, random_spaces: true });
        },
      },
    ],
  },
  {
    name: "Binær",
    options: [
      {
        name: "Til binær",
        entry: function (text: string) {
          return Binary.encode(text);
        },
      },
      {
        name: "Binær til tekst",
        entry: function (binary: string) {
          return Binary.decode(binary);
        },
      },
    ],
  },
  {
    name: "Blindskrift",
    options: [
      {
        name: "Til blindskrift",
        entry: function (text: string) {
          const encode = media_encode.encode(text, "blindskrift");
          const insertImageBeforeFirstNumber = (array:string[], imagePath:string) => {
            const newArray:string[] = [];
            let isNumberGroup = false;
            const numberRegex = /blindskrift\/(\d+)\.jpg/;
            for (let i = 0; i < array.length; i++) {
              // Check if the current item is a number
              const match = array[i].match(numberRegex);
              console.log('match', match)
              if (match) {
                if (!isNumberGroup) {
                  newArray.push(imagePath); // Add image before the first number in a group
                  isNumberGroup = true;
                }
              } else {
                isNumberGroup = false;
              }
              newArray.push(array[i]);
            }
            return newArray;
          };
          // Insert image path before each number group
          const newArray = insertImageBeforeFirstNumber(
            encode,
            "/algorithms/blindskrift/tal_start.jpg"
          );

         return newArray;
        },
      },
    ],
  },
  {
    name: "Dancing men",
    options: [
      {
        name: "Til dancing men",
        entry: function (text: string) {
          return media_encode.encode(text, "dangin_men");
        },
      },
    ],
  },
  {
    name: "Digital kode",
    options: [
      {
        name: "Til digital kode",
        entry: function (text: string) {
          return digital.encode(text);
        },
      },
      {
        name: "Fra digital kode",
        entry: function (text: string) {
          return digital.decode(text);
        },
      },
    ],
  },

  {
    name: "Fonetisk alfabet",
    options: [
      {
        name: "To Phonetic",
        entry: function (text: string) {
          return phonetic.encode(text);
        },
      },
      {
        name: "From Phonetic",
        entry: function (code: string) {
          return phonetic.decode(code);
        },
      },
    ],
  },
  {
    name: "Frimurerkode",
    options: [
      {
        name: "Til frimurerkode",
        entry: function (text: string) {
          return media_encode.encode(text, "frimurer");
        },
      },
    ],
  },

  {
    name: "Kodeordskode",
    options: [
      {
        name: "Oversæt",
        entry: function (text: string, word: string) {
          return kodeordsKode.encode(text, {
            word,
          });
        },
      },

      {
        name: "Løs oversættelsen",
        entry: function (text: string, word: string) {
          return kodeordsKode.encode(text, {
            word,
          });
        },
      },
    ],
  },
  {
    name: "Middelalder runer",
    options: [
      {
        name: "Til middelalder runner",
        entry: function (text: string) {
          return media_encode.encode(text, "middelalder_runer");
        },
      },
    ],
  },
  {
    name: "Morse",
    options: [
      {
        name: "Til morse",
        entry: function (text: string) {
          return morse.encode(text);
        },
      },
      {
        name: "Morse til tekst",
        entry: function (text: string) {
          return morse.decode(text);
        },
      },
    ],
  },
  {
    name: "Møllekode",
    options: [
      {
        name: "Til møllekode",
        entry: function (text: string) {
          return mollekode.encode(text);
        },
      },
      {
        name: "Fra møllekode",
        entry: function (code: string) {
          return mollekode.decode(code);
        },
      },
    ],
  },

  {
    name: "Semafor",
    options: [
      {
        name: "Til semafor",
        entry: function (text: string) {
          return media_encode.encode(text, "semafor");
        },
      },
    ],
  },

  {
    name: "SMS kode",
    options: [
      {
        name: "Til SMS kode",
        entry: function (text: string) {
          return sms.encode(text);
        },
      },
      {
        name: "Fra SMS kode",
        entry: function (code: string) {
          return sms.decode(code);
        },
      },
    ],
  },

  {
    name: "Talkode",
    options: [
      {
        name: "Til talkode",
        entry: function (text: string) {
          return talkode.encode(text);
        },
      },
      {
        name: "Fra talkode",
        entry: function (code: string) {
          return talkode.decode(code);
        },
      },
    ],
  },

  {
    name: "Ældre runer",
    options: [
      {
        name: "Til Ældreruner",
        entry: function (text: string) {
          return media_encode.encode(text, "Ældre_runer");
        },
      },
    ],
  },
];
