interface CodeOptions {
  word: string;
}
function checkRepeatedLetters(word: string) {
  const seen = new Set();
  for (const letter of word) {
    if (seen.has(letter)) {
      return false;
    }
    seen.add(letter);
  }
  return true;
}
const generateAlphabets = (word: string): string => {
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVXYZÆØÅ0123456789";
  const uniqueLetters = new Set<string>();

  // Add letters from the word to the set
  for (const letter of word.toUpperCase()) {
    uniqueLetters.add(letter);
  }

  let result = word.toUpperCase();

  // Add remaining letters from the alphabet
  for (const letter of alphabet) {
    if (!uniqueLetters.has(letter)) {
      result += letter;
    }
  }

  return result;
};
function isUpperCase(char: string): boolean {
  return char === char.toUpperCase();
}

function cleanText(text: string): string {
  return text.replace(/[^A-ZÆØÅ\s]/gi, "").toUpperCase();
}

export const kodeordsKode = {
  encode: (_text: string, options: CodeOptions): string => {
    if (!checkRepeatedLetters(options.word)) {
      throw new Error(
        "Fejl, du må ikke bruge et ord som indeholder det samme bogstav 2 gange."
      );
    }

    const text = cleanText(_text).replace(/\n+$/, "").trim().toUpperCase();
    if (text.toUpperCase().indexOf("W") > -1) {
      throw new Error("You can not use W");
    }
    const alphabets = generateAlphabets(options.word);
    const alphabet1 = alphabets.substring(0, 14);
    const alphabet2 = alphabets.substring(14, alphabets.length);
    console.log("alphabet1", alphabet1);
    console.log("alphabet2", alphabet2);
    let encoded = "";
    for (let i = 0; i < text.length; i++) {
      const char = text[i].toUpperCase();
      const index = alphabet1.indexOf(char);
      const index2 = alphabet2.indexOf(char);
      console.log("index,index2", index, index2);
      if (index > -1) {
        encoded += isUpperCase(text[i])
          ? alphabet2[index]
          : alphabet2[index].toLowerCase() || " ";
      } else {
        if (text[i] !== " ") {
          encoded += isUpperCase(text[i])
            ? alphabet1[index2]
            : alphabet1[index2].toLowerCase();
        } else {
          encoded += " ";
        }
      }
    }

    console.log("encoded", encoded);
    return encoded;
  },
  decode: (_code: string, options: CodeOptions): string => {
    if (!checkRepeatedLetters(options.word)) {
      throw new Error(
        "Fejl, du må ikke bruge et ord som indeholder det samme bogstav 2 gange."
      );
    }

    const code = _code.replace(/\n+$/, "").trim();
    const alphabets = generateAlphabets(options.word);
    const alphabet1 = alphabets.substring(0, 14);
    const alphabet2 = alphabets.substring(14, alphabets.length);
    console.log("alphabet1", alphabet1);
    console.log("alphabet2", alphabet2);
    let decoded = "";
    for (let i = 0; i < code.length; i++) {
      const char = code[i].toUpperCase();
      const index = alphabet1.indexOf(char);
      const index2 = alphabet2.indexOf(char);
      console.log("index,index2", index, index2);
      if (index > -1) {
        decoded += alphabet2[index];
      } else {
        decoded += alphabet1[index2];
      }
    }

    console.log("decode", decoded);
    return decoded;
  },
};

// Example usage

// const code = "SPEJD";

// const res = kodeordsKode.encode("All is ell", { word: code });
// console.log("res", res);
