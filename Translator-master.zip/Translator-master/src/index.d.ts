interface Option {
  name: string;
  entry: (string, ...options: any) => string | string[];
}
interface Algorithm {
  name: string;
  options: Option[];
}
interface Backward {
  text: string;
  no_spaces?: boolean | false;
  random_spaces?: boolean | false;
}

type MediaAlogrithms =
  | "blindskrift"
  | "dangin_men"
  | "frimurer"
  | "middelalder_runer"
  | "semafor"
  | "Ældre_runer";
type Order = "ascending" | "descending" | "withoutW" | "speechToText";

type ToBinaryOptions =
  | "binary"
  | "numberCode"
  | "ascii"
  | "removeSpaces"
  | "withoutW";

type FromBinaryOptions = "text" | "numberCode" | "ascii";

type Fremurer = "danish" | "english";

// Interface for the code translator
interface CodeTranslator {
  [key: string]: string;
}
