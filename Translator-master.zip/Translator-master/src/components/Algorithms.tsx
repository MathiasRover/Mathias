import { useEffect, useState } from "react";
import { algorithms } from "../utils";

export function Algorithms({
  onSelect,
}: {
  onSelect: (algorithm: Algorithm) => void;
}) {
  const [active, setActive] = useState(0);
  const [show, setShow] = useState(false);

  useEffect(() => {
    onSelect(algorithms[active]);
  }, [active, onSelect]);
  return (
    <div className="relative flex justify-center   w-full  max-w-md mx-auto">
      <div
        onClick={() => {
          setShow(!show);
        }}
        className="cursor-pointer flex justify-between w-full  items-center   p-2.5 rounded-[10px] border-[0.5px] border-[#575757]"
      >
        <div className="flex justify-center items-center relative gap-2.5">
          <p className="text-[22.938461303710938px] font-medium text-left text-[#575757]">
            {active > -1 ? algorithms[active].name : "Select Option"}
          </p>
        </div>
        <div className="flex justify-start items-start relative gap-2.5">
          <svg
            width={40}
            height={39}
            viewBox="0 0 40 39"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-[38.23px] h-[38.23px] relative"
            preserveAspectRatio="none"
          >
            <path
              fillRule="evenodd"
              clipRule="evenodd"
              d="M11.5686 14.803C10.9465 14.1809 9.93789 14.1809 9.31581 14.803C8.69372 15.4251 8.69372 16.4337 9.31581 17.0558L18.8735 26.6135C19.4956 27.2355 20.5042 27.2355 21.1263 26.6135L30.684 17.0558C31.306 16.4337 31.306 15.4251 30.684 14.803C30.0619 14.1809 29.0533 14.1809 28.4312 14.803L19.9999 23.2343L11.5686 14.803Z"
              fill="#575757"
            />
          </svg>
        </div>
      </div>
      <div
        className={`absolute left-0 right-0 top-[64px] z-50 ${
          show ? "" : "hidden"
        } h-[325px] overflow-y-scroll   rounded-bl-[20px] rounded-br-[20px] bg-white`}
        style={{ boxShadow: "0px 24px 48px -12px rgba(16,24,40,0.25)" }}
      >
        {algorithms.map((algorithm, index) => (
          <button
            onClick={() => {
              setActive(index);
              setShow(false);
            }}
            key={algorithm.name}
            className={`w-full flex justify-between items-center self-stretch relative px-11 py-5 bg-white`}
            style={{
              backgroundColor: `${active == index ? "#C4CBDF" : ""}`,
            }}
          >
            <p className=" text-md font-medium text-left text-[#313144]">
              {algorithm.name}
            </p>
          </button>
        ))}
      </div>
    </div>
  );
}
