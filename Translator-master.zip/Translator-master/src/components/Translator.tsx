import { ReactEventHandler, useCallback, useState } from "react";
import { Options } from "./Options";
import { Algorithms } from "./Algorithms";
import { useClipboard } from "use-clipboard-copy";
import userConverter from "../utils/converters";

export function FieldArea({
  label,
  placeholder,
  onChange,
}: {
  label: string;
  placeholder: string;
  value?: string;
  onChange?: React.ChangeEventHandler<HTMLTextAreaElement>;
}) {
  return (
    <div className="flex flex-col justify-start items-start relative gap-[18px] w-full">
      <p className="text-xl font-semibold text-center text-[#575757]">
        {label}
      </p>

      <textarea
        placeholder={placeholder}
        onChange={onChange}
        className="flex outline-none justify-start items-start w-full h-[175px] relative overflow-hidden gap-2.5 px-[22px] py-[30px] rounded-xl border-[3px] border-[#ffa400] text-base text-left placeholder::text-[#808191]"
      ></textarea>
    </div>
  );
}
export function Translator() {
  const [text, setText] = useState("");
  const [result, setResult] = useState<string[] | string>("");
  const [selected, setSelected] = useState<Option>();
  const [algorithm, setAlgorithm] = useState<Algorithm>();

  const [copied, setCopied] = useState(false);
  const { copy } = useClipboard();
  const [starts, setStarts] = useState({ start1: "A", start2: "K" });
  const [password, setPassword] = useState("SPEDJ");

  const { divRef, saveAsImage, saveAsPDF } = userConverter();
  const handleImageError: ReactEventHandler<HTMLImageElement> = (event) => {
    const img = event.target as HTMLImageElement;
    img.src = "placeholder.jpg";
  };

  const algorithmSelect = useCallback(
    (algorithm: Algorithm) => {
      setSelected(algorithm.options[0]);
      setAlgorithm(algorithm);
    },
    []
  );
  return (
    <div className="flex max-w-[720px] flex-col justify-center items-center gap-4 px-4 w-full">
      <Algorithms onSelect={algorithmSelect} />

      {algorithm?.name == "A-K kode" && (
        <div className="flex gap-4">
          <select
            value={starts.start1}
            onChange={(e) => {
              setStarts({
                ...starts,
                start1: e.target.value,
              });
            }}
            className="px-4 py-2 rounded-md bottom-0 outline-none"
          >
            {Array.from({ length: 26 }, (_, index) =>
              String.fromCharCode(65 + index)
            ).map((letter, index) => (
              <option key={index} value={letter}>
                {letter}
              </option>
            ))}
          </select>
          <select
            value={starts.start2}
            onChange={(e) => {
              setStarts({
                ...starts,
                start2: e.target.value,
              });
            }}
            className="px-4 py-2 rounded-md bottom-0 outline-none"
          >
            {Array.from({ length: 26 }, (_, index) =>
              String.fromCharCode(65 + index)
            ).map((letter, index) => (
              <option key={index} value={letter}>
                {letter}
              </option>
            ))}
          </select>
        </div>
      )}

      {algorithm?.name == "Kodeordskode" && (
        <div className="flex gap-4">
          <input
            onChange={(e) => {
              setPassword(e.target.value);
            }}
            placeholder="password"
            className="px-4 py-2 rounded-md bottom-0 outline-none border-2"
          />
        </div>
      )}

      <Options
        options={algorithm?.options}
        selected={selected?.name}
        onSelect={(option) => {
          setSelected(option);
        }}
      />

      <div className="w-full flex flex-col gap-4 justify-center items-center ">
        <FieldArea
          label="Input"
          placeholder="Type"
          onChange={(e) => {
            setText(e.target.value);
          }}
        />

        <button
          onClick={() => {
            if (algorithm?.name == "A-K kode") {
              setResult(selected!.entry(text, starts.start1, starts.start2));
            } else if (algorithm?.name == "Kodeordskode") {
              try {
                const data = selected!.entry(text, password);
                console.log('data', data)
                setResult(data);
              } catch (error) {
                alert(error);
              }
            } else {
              setResult(selected!.entry(text));
            }
          }}
          className="flex justify-center items-center relative gap-1 w-fit px-12 py-[18px] rounded-xl bg-[#44d62d]"
        >
          <p className="text-2xl font-medium text-center text-white">Oversæt</p>
        </button>
        <div className="flex flex-col justify-start items-start relative gap-[18px] w-full">
          <p className="text-xl font-semibold text-center text-[#575757]">
            Output
          </p>
          <div
            ref={divRef}
            className="flex flex-wrap h-[175px] overflow-y-scroll outline-none justify-start items-start w-full relative overflow-hidden gap-2.5 px-[22px] py-[30px] rounded-xl border-[3px] border-[#ffa400] text-base text-left placeholder::text-[#808191]"
          >
            {typeof result === "string" ? (
              <p
                style={{
                  wordBreak: "break-all",
                }}
              >
                {result}
              </p>
            ) : (
              result.map((img, index) => (
                <img
                  key={index}
                  src={img}
                  className={"image-with-fallback"}
                  onError={handleImageError}
                  style={{
                    maxWidth: "72px",
                    height: "auto",
                    // Optionally, you can specify fixed dimensions if necessary:
                    // width: "48px",
                    // height: "48px",
                  }}
                />
              ))
            )}
          </div>
        </div>
        <div className="flex justify-between items-center w-full flex-wrap gap-6">
          <button
            onClick={() => {
              if (!result) {
                alert("nothing to copy");
                return;
              }
              copy(result);
              setCopied(true);
              setTimeout(() => {
                setCopied(false);
              }, 1000);
            }}
            className="flex justify-start items-center relative gap-[11px]"
          >
            <svg
              width={23}
              height={26}
              viewBox="0 0 23 26"
              xmlns="http://www.w3.org/2000/svg"
              preserveAspectRatio="none"
              fill={`${copied ? "#2bbc62" : "#2B6EBC"}`}
            >
              <path d="M14.21 25.7307H4.88379C2.72982 25.7307 0.977539 23.9784 0.977539 21.8245V8.59204C0.977539 6.43807 2.72982 4.68579 4.88379 4.68579H14.21C16.3639 4.68579 18.1162 6.43807 18.1162 8.59204V21.8245C18.1162 23.9784 16.3639 25.7307 14.21 25.7307ZM4.88379 6.63892C3.8069 6.63892 2.93066 7.51515 2.93066 8.59204V21.8245C2.93066 22.9014 3.8069 23.7776 4.88379 23.7776H14.21C15.2868 23.7776 16.1631 22.9014 16.1631 21.8245V8.59204C16.1631 7.51515 15.2868 6.63892 14.21 6.63892H4.88379ZM22.0225 19.3831V4.63696C22.0225 2.48299 20.2702 0.730713 18.1162 0.730713H7.27637C6.73697 0.730713 6.2998 1.16788 6.2998 1.70728C6.2998 2.24667 6.73697 2.68384 7.27637 2.68384H18.1162C19.1931 2.68384 20.0693 3.56007 20.0693 4.63696V19.3831C20.0693 19.9225 20.5065 20.3596 21.0459 20.3596C21.5853 20.3596 22.0225 19.9225 22.0225 19.3831Z" />
            </svg>
            <span
              className={`text-[15px] font-light text-left ${
                copied ? "text-[#2bbc62]" : "text-[#2B6EBC]"
              }`}
            >
              {copied ? "Copied" : "Kopier"}
            </span>
          </button>
          <div className="flex justify-start items-start gap-6 flex-wrap">
            <button
              onClick={() => {
                const element = divRef.current;
                if (element) {
                  // Set the style properties as needed
                  element.style.height = "100%";
                  element.style.backgroundColor = "transparent";
                  element.style.borderWidth = "0px";
                }
                saveAsImage("png");

                if (element) {
                  element.style.height = "175px";
                  element.style.borderWidth = "3px";
                  element.style.backgroundColor = "white";
                }
              }}
              className="flex justify-center items-center relative gap-1 px-4 py-3 rounded-xl bg-[#2b6ebc]"
            >
              <img className="w-2.5 h-4" src={"/images/download.svg"} />
              <p className="text-sm font-medium text-center text-white">
                Gem som PNG
              </p>
            </button>
            <button
              onClick={() => {
                const element = divRef.current;
                if (element) {
                  // Set the style properties as needed
                  element.style.height = "100%";
                }
                saveAsPDF();
                if (element) {
                  element.style.height = "175px";
                }
              }}
              className="flex justify-center items-center relative gap-1 px-4 py-3 rounded-xl bg-[#2b6ebc]"
            >
              <img className="w-2.5 h-4" src={"/images/download.svg"} />
              <p className="text-sm font-medium text-center text-white">
                Gem som PDF
              </p>
            </button>
            <button
              onClick={() => {
                const element = divRef.current;
                if (element) {
                  // Set the style properties as needed
                  element.style.height = "100%";
                  element.style.borderWidth = "0px";
                }
                saveAsImage("jpeg");

                if (element) {
                  element.style.height = "175px";
                  element.style.borderWidth = "3px";
                }
              }}
              className="flex justify-center items-center relative gap-1 px-4 py-3 rounded-xl bg-[#2b6ebc]"
            >
              <img className="w-2.5 h-4" src={"/images/download.svg"} />
              <p className="text-sm font-medium text-center text-white">
                Gem som JPEG
              </p>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
