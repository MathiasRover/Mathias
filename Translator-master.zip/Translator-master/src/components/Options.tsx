function CheckBox({
  acitve,
  label,
  onClick,
}: {
  acitve: boolean;
  label: string;
  onClick: React.MouseEventHandler<HTMLDivElement> | undefined;
}) {
  return (
    <div
      onClick={onClick}
      className="flex justify-start items-center relative gap-2.5"
    >
      {acitve ? (
        <svg
          width={25}
          height={25}
          viewBox="0 0 25 25"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="flex-grow-0 flex-shrink-0"
          preserveAspectRatio="none"
        >
          <path
            d="M0.5 4.23071C0.5 2.02157 2.29086 0.230713 4.5 0.230713H20.5C22.7091 0.230713 24.5 2.02157 24.5 4.23071V20.2307C24.5 22.4399 22.7091 24.2307 20.5 24.2307H4.5C2.29086 24.2307 0.5 22.4399 0.5 20.2307V4.23071Z"
            fill="#5F75EE"
          />
          <path
            d="M16.1402 8.42596C16.2008 8.36416 16.2731 8.31507 16.3529 8.28155C16.4326 8.24804 16.5183 8.23077 16.6048 8.23077C16.6914 8.23077 16.777 8.24804 16.8568 8.28155C16.9366 8.31507 17.0089 8.36416 17.0694 8.42596C17.3233 8.68245 17.3268 9.09691 17.0783 9.35784L11.8305 15.5615C11.771 15.6269 11.6987 15.6795 11.618 15.716C11.5374 15.7525 11.4502 15.7722 11.3618 15.7739C11.2733 15.7755 11.1854 15.7591 11.1035 15.7257C11.0216 15.6922 10.9473 15.6424 10.8853 15.5792L7.69212 12.3434C7.56897 12.2178 7.49999 12.0489 7.49999 11.873C7.49999 11.6971 7.56897 11.5282 7.69212 11.4026C7.75269 11.3408 7.82498 11.2917 7.90476 11.2582C7.98454 11.2247 8.0702 11.2074 8.15673 11.2074C8.24326 11.2074 8.32892 11.2247 8.4087 11.2582C8.48848 11.2917 8.56077 11.3408 8.62134 11.4026L11.33 14.1477L16.1225 8.44549C16.128 8.43863 16.1339 8.43211 16.1402 8.42596Z"
            fill="white"
          />
        </svg>
      ) : (
        <svg
          width={25}
          height={25}
          viewBox="0 0 25 25"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="flex-grow-0 flex-shrink-0"
          preserveAspectRatio="none"
        >
          <path
            d="M1.25 4.23071C1.25 2.43579 2.70507 0.980713 4.5 0.980713H20.5C22.2949 0.980713 23.75 2.43579 23.75 4.23071V20.2307C23.75 22.0256 22.2949 23.4807 20.5 23.4807H4.5C2.70508 23.4807 1.25 22.0256 1.25 20.2307V4.23071Z"
            stroke="#2B6EBC"
            strokeWidth="1.5"
          />
        </svg>
      )}
      <div className="flex justify-start items-center relative gap-2.5">
        <p className="text-[22px] text-left text-[#575757]">{label}</p>
      </div>
    </div>
  );
}
export function Options({
  selected,
  options,
  onSelect,
}: {
  selected?: string;
  options?: Option[];
  onSelect: (option: Option) => void;
}) {
  return (
    <div className="flex flex-wrap items-center justify-center gap-10 ">

      {options?.map((option, index) =>
        option.name ? (
          <CheckBox
            acitve={selected === option.name}
            label={option.name}
            key={index}
            onClick={() => {
              console.log('option', option)
              onSelect(option);
            }}
          />
        ) : (
          <></>
        ),
      )}
    </div>
  );
}
