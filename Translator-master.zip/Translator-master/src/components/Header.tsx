import { useState } from "react";
import { Link } from "react-router-dom";

export function Header() {
  const navigation = [
    {
      name: "Forside",
      route: "/",
    },
    {
      name: "Forklaring",
      route: "/explanation",
    },
  ];
  const [acitve, setActive] = useState(0);
  return (
    <div
      className="flex flex-col justify-center sm:items-center sm:justify-between gap-12 sm:flex-row items-center flex-wrap w-full px-8 py-6 bg-white"
      style={{ boxShadow: "0px 15px 30px 0 rgba(237,237,237,0.7)" }}
    >
      <div className="flex justify-between items-center   relative">
        <img src="/images/logo.png" className="w-12 h-12" />

        <p className="ml-3 text-[22px] text-left text-black">Spejderkoder.dk</p>
      </div>
      <div className="flex flex-wrap justify-between items-center gap-12  relative">
        {navigation.map(({ name, route }, index) => (
          <Link
            to={route as string}
            onClick={() => {
              setActive(index);
            }}
            key={index}
            className={`text-xl text-center ${
              acitve === index ? "font-semibold" : ""
            } text-[#575757]`}
          >
            {name}
          </Link>
        ))}
      </div>
    </div>
  );
}
